import java.io.*;  
public class example {  
    public static void main(String[] args) {  
  
        try {  
            File a = new File("harika.txt");  
            if (a.createNewFile()) {  
                System.out.println("New File is created!");  
            } else {  
                System.out.println("File already exists.");  
            }  
        } catch (IOException e) {  
            e.printStackTrace();  
        }  
  
    }  
} 