import java.io.*;
public class example{
 public static void main(String args[])throws Exception{
  
  ObjectInputStream in=new ObjectInputStream(new FileInputStream("f.txt"));
  student s=(student)in.readObject();
  System.out.println(s.id+" "+s.name);

  in.close();
 }
}