import java.io.Serializable;

public class student implements Serializable{
 
	private static final long serialVersionUID = 1L;
int id;
 String name;
 public student(int id, String name) {
  this.id = id;
  this.name = name;
 }
}
